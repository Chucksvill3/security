package com.example.dnp279_lab3.model;

public class ResponseTeam {
    private String id;
    private String teamName;
    private String leaderName;
    private String info;

    public ResponseTeam(String id,String teamName, String leaderName,String info){
        this.id = id;
        this. teamName = teamName;
        this.leaderName = leaderName;
        this.info = info;
    }
    public String getId(){
      return id;
    }
    public void setId(String id){
        this.id = id;
    }
    public String getTeamName(){
        return teamName;

    }
    public void setTeamName(){
        this.teamName = teamName;
    }

    public String getLeaderName() {
        return leaderName;
    }

    public void setLeaderName(String leaderName) {
        this.leaderName = leaderName;
    }
    public String getInfo(){
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
