package com.example.dnp279_lab3.model;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;

public class IncidentTracker {
    private ArrayList<Incident> incidents;

    public IncidentTracker() {
        this.incidents = new ArrayList<>();
    }

    public void loadIncidents(Context context) {
        AssetManager assetManager = context.getAssets();
        String line;

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(assetManager.open("incidents.csv")))) {

            while ((line = reader.readLine()) != null) {
                String[] delimiter = line.split(",");
                Incident incident = new Incident(
                        delimiter[0], delimiter[1], delimiter[2],
                        delimiter[3], delimiter[4], delimiter[5]
                );
                incidents.add(incident);
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading incidents.csv", e);
        }
    }

    public Incident getIncident(String idOrType) {
        for (Incident incident : incidents) {
            if (incident.getId().equalsIgnoreCase(idOrType) ||
                    incident.getType().equalsIgnoreCase(idOrType)) {
                return incident;
            }
        }
        return null;
    }

    public ArrayList<Incident> getAllIncidents() {
        return incidents;
    }
}
